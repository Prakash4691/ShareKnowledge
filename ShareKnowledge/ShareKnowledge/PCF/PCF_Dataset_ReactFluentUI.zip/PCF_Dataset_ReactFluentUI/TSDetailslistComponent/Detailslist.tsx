import * as React from "react";
import { IInputs } from "./generated/ManifestTypes";
import {
  DetailsList,
  DetailsListLayoutMode,
  Selection,
  IColumn,
  SelectionMode,
} from "@fluentui/react/lib/DetailsList";
import { MarqueeSelection } from "@fluentui/react/lib/MarqueeSelection";
import { mergeStyleSets } from "@fluentui/react/lib/Styling";
import {
  initializeIcons,
  ScrollablePane,
  Sticky,
  StickyPositionType,
  CommandBar,
  ICommandBarItemProps,
  ScrollbarVisibility,
} from "@fluentui/react";

// Initialize icons in case this example uses them
initializeIcons();

const styles = mergeStyleSets({
  scrollableContainer: {
    position: "relative",
    minHeight: "70vh",
    overflow: "auto",
  },
});

export interface IAttributeValue {
  name: string;
  value: string;
}

export interface IDetailsListCompactExampleItem {
  key: string;
  fullname: string;
  emailaddress1: string;
  parentcustomerid: string;
  telephone1: string;
}

export interface IDetailsListCompactExampleState {
  items: IDetailsListCompactExampleItem[];
  columns: IColumn[];
  triggerNavigate?: (id: string) => void;
  totalResultCount?: number;
  triggerPaging?: (pageCommand: string) => void;
  context?: ComponentFramework.Context<IInputs>;
}

export class DetailsListCompact extends React.Component<
  IDetailsListCompactExampleState,
  IDetailsListCompactExampleState
> {
  private _selection: Selection;

  constructor(props: IDetailsListCompactExampleState) {
    super(props);
    this.state = {
      items: this.props.items,
      columns: this.props.columns,
      context: this.props.context,
    };

    for (let index = 0; index < this.state.columns.length; index++) {
      this.state.columns[index].onColumnClick = this._onColumnClick;
    }

    this._selection = new Selection({
      onSelectionChanged: () => {
        this.onRowSelection();
      },
    });
  }

  private onRowSelection = () => {
    let selectedRowId: string;
    let selectedCardIndex: number;
    let _allSelectedRows: any = [];
    let selectedItems = this._selection.getSelectedIndices();
    const { items, context } = this.state;
    selectedItems.map(function (index) {
      selectedRowId = items[index].key;
      selectedCardIndex = _allSelectedRows.findIndex((element: any) => {
        return element == selectedRowId;
      });

      if (selectedCardIndex >= 0) {
        _allSelectedRows.splice(selectedCardIndex, 1);
      } else {
        _allSelectedRows.push(selectedRowId);
      }
    });
    context?.parameters.Detailslist.setSelectedRecordIds(_allSelectedRows);
  };

  componentDidMount() {
    let newItems = this.copyAndSort(this.state.items, "fullname", true);
    this.setState({
      items: newItems,
      columns: this.state.columns,
    });
  }

  componentDidUpdate() {
    if (this.state.items.length !== this.props.items.length) {
      let newItems = this.copyAndSort(this.props.items, "fullname", true);
      for (let index = 0; index < this.props.columns.length; index++) {
        this.props.columns[index].onColumnClick = this._onColumnClick;
      }

      this.setState({
        items: newItems,
        columns: this.props.columns,
      });
    }
  }

  public _onColumnClick = (
    ev: React.MouseEvent<HTMLElement>,
    column: IColumn
  ): void => {
    const newColumns: IColumn[] = this.state.columns.slice();
    const currColumn: IColumn = newColumns.filter(
      (currCol) => column.key === currCol.key
    )[0];
    newColumns.forEach((newCol: IColumn) => {
      if (newCol === currColumn) {
        currColumn.isSortedDescending = !currColumn.isSortedDescending;
        currColumn.isSorted = true;
      } else {
        newCol.isSorted = false;
        newCol.isSortedDescending = true;
      }
    });
    const newItems = this.copyAndSort(
      this.state.items,
      currColumn.fieldName!,
      currColumn.isSortedDescending
    );
    this.setState({
      columns: newColumns,
      items: newItems,
    });
  };

  private copyAndSort = function _copyAndSort<T>(
    items: T[],
    columnKey: string,
    isSortedDescending?: boolean
  ): T[] {
    const key = columnKey as keyof T;
    return items
      .slice(0)
      .sort((a: T, b: T) =>
        (isSortedDescending ? a[key] < b[key] : a[key] > b[key]) ? 1 : -1
      );
  };

  private _getKey(item: any, index?: number): string {
    return item.key;
  }

  // private openRecord(id: string): void {
  //   let record =
  //     this.context.parameters.Detailslist.records[id].getNamedReference();
  //   this.context.navigation.openForm({
  //     entityName: record.etn!,
  //     entityId: record.id.guid,
  //   });
  // }

  //   private _renderItemColumn(
  //     item: IDetailsListCompactExampleItem,
  //     index: number | undefined,
  //     column: IColumn | undefined
  //   ) {
  //     const fieldContent = item[
  //       column?.fieldName as keyof IDetailsListCompactExampleItem
  //     ] as string;
  //     const fieldKey = item[
  //       column?.key as keyof IDetailsListCompactExampleItem
  //     ] as string;
  //     switch (column?.key) {
  //       case "fullname":
  //         return (
  //           <Link id={item.key} onClick={(e) => this.openRecord(item.key)}>
  //             {fieldContent}
  //           </Link>
  //         );
  //       default:
  //         return <span>{fieldContent}</span>;
  //     }
  //   }

  private rightCommands: ICommandBarItemProps[] = [
    {
      key: "next",
      name: `Load more..`,
      iconProps: {
        iconName: "ChevronRight",
      },
      disabled: this.props.items.length == this.props.totalResultCount,
      onClick: () => {
        if (this.props.triggerPaging) {
          this.props.triggerPaging("next");
        }
      },
    },
  ];

  private leftCommands: ICommandBarItemProps[] = [];

  render() {
    const { items, columns } = this.state;
    return (
      <>
        <Sticky stickyPosition={StickyPositionType.Header}>
          <CommandBar farItems={this.rightCommands} items={this.leftCommands} />
        </Sticky>
        <MarqueeSelection selection={this._selection}>
          <ScrollablePane
            className={styles.scrollableContainer}
            scrollbarVisibility={ScrollbarVisibility.auto}
          >
            <DetailsList
              compact={true}
              items={
                items.length == this.props.items.length
                  ? items
                  : this.props.items
              }
              columns={
                items.length == this.props.items.length
                  ? columns
                  : this.props.columns
              }
              getKey={this._getKey}
              setKey="none"
              isHeaderVisible={true}
              layoutMode={DetailsListLayoutMode.justified}
              selection={this._selection}
              selectionPreservedOnEmptyClick={true}
              ariaLabelForSelectionColumn="Toggle selection"
              ariaLabelForSelectAllCheckbox="Toggle selection for all items"
              checkButtonAriaLabel="select row"
              selectionMode={SelectionMode.multiple}
              usePageCache={true}
              //onRenderItemColumn={this._renderItemColumn}
            />
          </ScrollablePane>
        </MarqueeSelection>
      </>
    );
  }
}
