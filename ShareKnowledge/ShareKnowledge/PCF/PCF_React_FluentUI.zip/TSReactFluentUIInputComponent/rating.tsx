import * as React from "react";
import { Rating, RatingSize, initializeIcons } from "@fluentui/react";

initializeIcons(); //this is to render elements from fluent UI. without this method no elements will render in DOM.

export interface IRating {
  rating: number;
  onChange: (rating: number) => void;
}

export class RatingClass extends React.Component<IRating> {
  constructor(props: any) {
    super(props);
    this.onRatingChange = this.onRatingChange.bind(this);
  }

  //on change of rating to trigger this event.
  onRatingChange(e: React.ChangeEvent<HTMLElement>) {
    let ratingFirstChild: any = e.currentTarget.firstChild!;
    let ratingValue: string = ratingFirstChild.innerText;
    this.props.onChange(parseInt(ratingValue));
  }

  render() {
    return (
      <div>
        <Rating
          max={5}
          size={RatingSize.Large}
          rating={this.props.rating}
          aria-label="Large stars"
          ariaLabelFormat="{0}"
          onChange={this.onRatingChange}
        ></Rating>
      </div>
    );
  }
}
